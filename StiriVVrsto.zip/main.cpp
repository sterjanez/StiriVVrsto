#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif

#include <iostream>

using namespace std;

#include <tchar.h>
#include <windows.h>

const int MaxSirina = 20;
const int MaxVisina = 20;

class IGRA
{
    public:
        int Matrika[MaxSirina][MaxVisina]; // igralna tabela; matrika[i][j] == 0, 1 ali 2;
                                       // 0 = prazno polje, 1 ali 2 = en od igralcev;
        int V_Vrsto; // koliko v vrsto igramo, vsaj 4
        int Sirina, Visina; // velikost igralne tabele, oboje vsaj 1
        int Igralec_Zacel; // igralec, ki je zacel igro
        int Igralec; // igralec na potezi
        void Inicializiraj(int v_vrsto, int sirina, int visina, int prvi_igralec)
        {
            V_Vrsto = v_vrsto;
            Sirina = sirina;
            Visina = visina;
            Igralec_Zacel = prvi_igralec;
            Igralec = prvi_igralec;
            for(int i = 0; i != sirina; i++)
                for(int j = 0; j != visina; j++)
                    Matrika[i][j] = 0;
        }
        int Visina_Stolpca(int i) // visina i-tega stolpca
        {
            for(int j = 0; j != Visina; j++)
                if(Matrika[i][j] == 0) return j;
            return Visina;
        }
        bool Linija(int igralec, int i0, int j0, int di, int dj, int n) // v liniji dolzine V_Vrsto
        // zacensi z (i0,j0) in smernim vektorjem (di,dj) ima igralec vsaj n svojih krogcev,
        // nasprotni pa nobenega
        {
            int stej = 0, i, j;
            for(int k = 0; k != V_Vrsto; k++)
            {
                i = i0 + k * di;
                j = j0 + k * dj;
                if(i < 0 || i >= Sirina || j < 0 || j >= Visina || Matrika[i][j] == 3 - igralec) return FALSE;
                if(Matrika[i][j] == igralec) stej++;
            }
            return stej >= n;
        }
        int Status() // -1 = ni konec, 0 = remi, 1 ali 2 = zmagal en od igralcev
        {
            for(int i = 0; i != Sirina; i++)
                for(int j = 0; j != Visina; j++)
                    for(int igralec = 1; igralec != 3; igralec++)
                        if(Linija(igralec, i, j, 1, 0, V_Vrsto) ||
                           Linija(igralec, i, j, 0, 1, V_Vrsto) ||
                           Linija(igralec, i, j, 1, 1, V_Vrsto) ||
                           Linija(igralec, i, j, 1, -1, V_Vrsto))
                            return igralec;
            for(int i = 0; i != Sirina; i++)
                if(Visina_Stolpca(i) < Visina) return -1;
            return 0;
        }
        bool Nevarnost(int igralec, int i, int n, bool navp)
        // ce bi igralec vrgel v polje i, bi imel "vsaj n v vrsto",
        // to pomeni vsaj n polj znotraj linije V_Vrsto polj, v kateri nasprotni igralec se nima polj;
        // zadnji parameter obravnava, ali upostevamo tudi navpicno linijo
        {
            if(Visina_Stolpca(i) == Visina) return FALSE;
            int j = Visina_Stolpca(i);
            Matrika[i][j] = igralec;
            for(int d = -V_Vrsto + 1; d != 1; d++)
                if((i + d >= 0 && Linija(igralec, i + d, j, 1, 0, n)) ||
                   (j + d >= 0 && Linija(igralec, i, j + d, 0, 1, n) && navp) ||
                   (i + d >= 0 && j + d >= 0 && Linija(igralec, i + d, j + d, 1, 1, n)) ||
                   (i + d >= 0 && j - d < Visina && Linija(igralec, i + d, j - d, 1, -1, n)))
                {
                    Matrika[i][j] = 0;
                    return TRUE;
                }
            Matrika[i][j] = 0;
            return FALSE;
        }
};

class GRAFIKA
{
    public:
        int Odmik_Levo, Odmik_Zgoraj; // odmik tabele znotraj "client area"
        int Debelina_Robu, Velikost_Polja; // debelina robu tabele in velikost igralnega polja za 1 krogec
        int Odmik_Velikega_Kroga, Odmik_Malega_Kroga; // odmik krogca in notranjega krogca
        int Debelina_Robu_Kroga; // robova obeh krogcev
        COLORREF Barva_Robu, Barva_1, Barva_2, Barva_Robu_1, Barva_Robu_2; // barva za igralca 1 in igralca 2
        void Inicializiraj(HWND hwnd, IGRA Igra, COLORREF barva_1, COLORREF barva_robu_1, COLORREF barva_2, COLORREF barva_robu_2)
        {
            RECT prav;
            GetClientRect(hwnd, &prav);
            Debelina_Robu = max(prav.right / (Igra.Sirina * 40 + 1), 1l);
            Debelina_Robu_Kroga = Debelina_Robu;
            Velikost_Polja = min((prav.right - Debelina_Robu) / Igra.Sirina - Debelina_Robu,
                                 (prav.bottom - Debelina_Robu) / Igra.Visina - Debelina_Robu);
            Odmik_Velikega_Kroga = Velikost_Polja / 10;
            Odmik_Malega_Kroga = Velikost_Polja / 5;
            Odmik_Levo = (prav.right - (Velikost_Polja + Debelina_Robu) * Igra.Sirina - Debelina_Robu) / 2;
            Odmik_Zgoraj = (prav.bottom - (Velikost_Polja + Debelina_Robu) * Igra.Visina - Debelina_Robu) / 2;
            Barva_1 = barva_1;
            Barva_Robu_1 = barva_robu_1;
            Barva_2 = barva_2;
            Barva_Robu_2 = barva_robu_2;
            Barva_Robu = RGB(0, 0, 0);
        }
    private:
        void Narisi_Polje(HDC hDC, IGRA Igra, int i, int j) // narise 1 polje, a ga ne osvezi (Invalidate);
        {
            if(Igra.Matrika[i][j] == 0) return;
            HPEN pen;
            HBRUSH brush;
            if(Igra.Matrika[i][j] == 1)
            {
                pen = CreatePen(PS_SOLID, Debelina_Robu_Kroga, Barva_Robu_1);
                brush = CreateSolidBrush(Barva_1);
            }
            else
            {
                pen = CreatePen(PS_SOLID, Debelina_Robu_Kroga, Barva_Robu_2);
                brush = CreateSolidBrush(Barva_2);
            }
            HGDIOBJ stariPen = SelectObject(hDC, pen);
            HGDIOBJ stariBrush = SelectObject(hDC, brush);
            Ellipse(hDC,
                    Odmik_Levo + i * (Velikost_Polja + Debelina_Robu) + Debelina_Robu + Odmik_Velikega_Kroga,
                    Odmik_Zgoraj + (Igra.Visina - 1 - j) * (Velikost_Polja + Debelina_Robu) + Debelina_Robu + Odmik_Velikega_Kroga,
                    Odmik_Levo + (i + 1) * (Velikost_Polja + Debelina_Robu) - Odmik_Velikega_Kroga,
                    Odmik_Zgoraj + (Igra.Visina - j) * (Velikost_Polja + Debelina_Robu) - Odmik_Velikega_Kroga);
            Ellipse(hDC,
                    Odmik_Levo + i * (Velikost_Polja + Debelina_Robu) + Debelina_Robu + Odmik_Malega_Kroga,
                    Odmik_Zgoraj + (Igra.Visina - 1 - j) * (Velikost_Polja + Debelina_Robu) + Debelina_Robu + Odmik_Malega_Kroga,
                    Odmik_Levo + (i + 1) * (Velikost_Polja + Debelina_Robu) - Odmik_Malega_Kroga,
                    Odmik_Zgoraj + (Igra.Visina - j) * (Velikost_Polja + Debelina_Robu) - Odmik_Malega_Kroga);
            SelectObject(hDC, stariPen);
            SelectObject(hDC, stariBrush);
            DeleteObject(pen);
            DeleteObject(brush);
        }
    public:
        void Narisi_Tabelo(HDC hDC, IGRA Igra) // narise tabelo, brez osvezevanja (InvalidateRect)
        {
            HPEN pen = CreatePen(PS_SOLID, 1, Barva_Robu);
            HBRUSH brush = CreateSolidBrush(Barva_Robu);
            HGDIOBJ stariPen = SelectObject(hDC, pen);
            HGDIOBJ stariBrush = SelectObject(hDC, brush);
            for(int i = 0; i <= Igra.Sirina; i++)
                Rectangle(hDC,
                          Odmik_Levo + i * (Velikost_Polja + Debelina_Robu),
                          Odmik_Zgoraj,
                          Odmik_Levo + i * (Velikost_Polja + Debelina_Robu) + Debelina_Robu,
                          Odmik_Zgoraj + Igra.Visina * (Velikost_Polja + Debelina_Robu) + Debelina_Robu);
            for(int j = 0; j <= Igra.Visina; j++)
                Rectangle(hDC,
                          Odmik_Levo,
                          Odmik_Zgoraj + j * (Velikost_Polja + Debelina_Robu),
                          Odmik_Levo + Igra.Sirina * (Velikost_Polja + Debelina_Robu) + Debelina_Robu,
                          Odmik_Zgoraj + j * (Velikost_Polja + Debelina_Robu) + Debelina_Robu);
            SelectObject(hDC, stariPen);
            SelectObject(hDC, stariBrush);
            DeleteObject(pen);
            DeleteObject(brush);
            for(int i = 0; i != Igra.Sirina; i++)
                for(int j = 0; j != Igra.Visina; j++)
                   Narisi_Polje(hDC, Igra, i, j);
        }
        int Preberi_Klik(HWND hwnd, POINT p, IGRA Igra)
        // p so koordinate klika (znotraj client area), vrne i oziroma -1,
        // ce smo kliknili zunaj ali je stolpec ze poln
        {
            if(p.x < Odmik_Levo) return -1;
            if(p.x >= Odmik_Levo + (Velikost_Polja + Debelina_Robu) * Igra.Sirina) return -1;
            if(p.y < Odmik_Zgoraj) return -1;
            if(p.y >= Odmik_Zgoraj + (Velikost_Polja + Debelina_Robu) * Igra.Visina) return -1;
            if((p.x - Odmik_Levo) % (Velikost_Polja + Debelina_Robu) < Debelina_Robu) return -1;
            int i = (p.x - Odmik_Levo) / (Velikost_Polja + Debelina_Robu);
            int j = Igra.Visina_Stolpca(i);
            if(j == Igra.Visina) return -1;
            return i;
        }
        void Osvezi_Polje(HWND hwnd, IGRA Igra, int i, int j)
        {
            RECT prav = {Odmik_Levo + i * (Velikost_Polja + Debelina_Robu) + Debelina_Robu,
            Odmik_Zgoraj + (Igra.Visina - j - 1) * (Velikost_Polja + Debelina_Robu) + Debelina_Robu,
            Odmik_Levo + (i + 1) * (Velikost_Polja + Debelina_Robu),
            Odmik_Zgoraj + (Igra.Visina - j) * (Velikost_Polja + Debelina_Robu)};
            InvalidateRect(hwnd, &prav, TRUE);
        }
};

int RacunalniskaAnaliza(IGRA Igra)
{
    int prednostnaLista[Igra.Sirina];
    for(int k = 0; k != Igra.Sirina; k++)
        prednostnaLista[k] = (Igra.Sirina - 1) / 2 + ((k + 1) / 2) * (2 * (k % 2) - 1);
    int igralec = Igra.Igralec;
    int nasp = 3 - igralec;
    for(int k = 0; k != Igra.Sirina; k++)
        if(Igra.Nevarnost(igralec, prednostnaLista[k], Igra.V_Vrsto, TRUE))
            return prednostnaLista[k];
    for(int k = 0; k != Igra.Sirina; k++)
        if(Igra.Nevarnost(nasp, prednostnaLista[k], Igra.V_Vrsto, TRUE))
            return prednostnaLista[k];
    int i, j;
    for(int n = Igra.V_Vrsto - 1; n != 2; n--)
    {
        for(int k = 0; k != Igra.Sirina; k++)
            if(Igra.Nevarnost(nasp, prednostnaLista[k], n, FALSE))
            {
                i = prednostnaLista[k];
                j = Igra.Visina_Stolpca(i);
                Igra.Matrika[i][j] = igralec;
                if(!Igra.Nevarnost(igralec, i, n + 1, FALSE) && !Igra.Nevarnost(nasp, i, n + 1, FALSE))
                {
                    Igra.Matrika[i][j] = 0;
                    return i;
                }
                Igra.Matrika[i][j] = 0;
            }
        for(int k = 0; k != Igra.Sirina; k++)
            if(Igra.Nevarnost(igralec, prednostnaLista[k], n, FALSE))
            {
                i = prednostnaLista[k];
                j = Igra.Visina_Stolpca(i);
                Igra.Matrika[i][j] = igralec;
                if(!Igra.Nevarnost(igralec, i, n + 1, FALSE) && !Igra.Nevarnost(nasp, i, n + 1, FALSE))
                {
                    Igra.Matrika[i][j] = 0;
                    return i;
                }
                Igra.Matrika[i][j] = 0;
            }
    }
    for(int n = 3; n <= Igra.V_Vrsto; n++)
        for(int k = 0; k != Igra.Sirina; k++)
            if(Igra.Visina_Stolpca(prednostnaLista[k]) != Igra.Visina)
            {
                i = prednostnaLista[k];
                j = Igra.Visina_Stolpca(i);
                Igra.Matrika[i][j] = igralec;
                if(!Igra.Nevarnost(igralec, i, n, FALSE) && !Igra.Nevarnost(nasp, i, n, FALSE))
                {
                    Igra.Matrika[i][j] = 0;
                    return i;
                }
                Igra.Matrika[i][j] = 0;
            }
    for(int k = 0; k != Igra.Sirina; k++)
        if(Igra.Visina_Stolpca(prednostnaLista[k]) != Igra.Visina)
        {
            i = prednostnaLista[k];
            j = Igra.Visina_Stolpca(i);
            Igra.Matrika[i][j] = igralec;
            if(!Igra.Nevarnost(nasp, i, Igra.V_Vrsto, FALSE))
            {
                Igra.Matrika[i][j] = 0;
                return i;
            }
            Igra.Matrika[i][j] = 0;
        }
    for(int k = 0; k != Igra.Sirina; k++)
        if(Igra.Visina_Stolpca(prednostnaLista[k]) != Igra.Visina)
            return prednostnaLista[k];
}

void VprasajInZacniNovoIgro(HWND hwnd, IGRA& Igra, GRAFIKA& Grafika, int zmagali) // zmagali = 1, 0 ali -1
{
    LPCSTR s;
    switch(zmagali)
    {
        case 1:
            s = "Zmagali ste! Nova igra?";
            break;
        case 0:
            s = "Remi! Nova igra?";
            break;
        case -1:
            s = "Izgubili ste! Nova igra?";
    }
    if(MessageBoxA(hwnd, s, "Konec igre", MB_YESNO) == IDNO)
    {
        PostQuitMessage(0);
        return;
    }
    Igra.Inicializiraj(4, 7, 6, 1);
    Grafika.Inicializiraj(hwnd, Igra, RGB(255, 0, 0), RGB(100, 0, 0), RGB(0, 255, 0), RGB(0, 100, 0));
    InvalidateRect(hwnd, NULL, TRUE);
}

void Klik(HWND hwnd, POINT p, IGRA& Igra, GRAFIKA Grafika)
{
    int i = Grafika.Preberi_Klik(hwnd, p, Igra);
    if(i == -1) return;
    int j = Igra.Visina_Stolpca(i);
    Igra.Matrika[i][j] = Igra.Igralec;
    Grafika.Osvezi_Polje(hwnd, Igra, i, j);
    int status = Igra.Status();
    if(status != -1)
    {
        VprasajInZacniNovoIgro(hwnd, Igra, Grafika, min(status, 1));
        return;
    }
    Igra.Igralec = 3 - Igra.Igralec;
    i = RacunalniskaAnaliza(Igra);
    j = Igra.Visina_Stolpca(i);
    Igra.Matrika[i][j] = Igra.Igralec;
    Grafika.Osvezi_Polje(hwnd, Igra, i, j);
    status = Igra.Status();
    if(status != -1)
    {
        VprasajInZacniNovoIgro(hwnd, Igra, Grafika, -min(status, 1));
        return;
    }
    Igra.Igralec = 3 - Igra.Igralec;
}

bool Pridobi_Podatke(IGRA& Igra)
{
    Igra.Inicializiraj(4,7,6,1);
    return TRUE;
}



/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/*  Make the class name into a global variable  */
TCHAR szClassName[ ] = _T("CodeBlocksWindowsApp");

IGRA Igra;
GRAFIKA Grafika;

int WINAPI WinMain (HINSTANCE hThisInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR lpszArgument,
                     int nCmdShow)
{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */

    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use Windows's default colour as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           _T("�tiri v vrsto"),       /* Title Text */
   //        WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, /* default window */
           WS_OVERLAPPEDWINDOW,
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           600,                 /* The programs width */
           400,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    if(!Pridobi_Podatke(Igra)) PostQuitMessage(0);
    Grafika.Inicializiraj(hwnd, Igra, RGB(255, 0, 0), RGB(100, 0, 0), RGB(0, 0, 255), RGB(0, 0, 100));
    InvalidateRect(hwnd, NULL, TRUE);

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nCmdShow);

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}

/*  This function is called by the Windows function DispatchMessage()  */

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)                  /* handle the messages */
    {
        case WM_LBUTTONDOWN:
            POINT p;
            if(GetCursorPos(&p) && ScreenToClient(hwnd, &p))
                Klik(hwnd, p, Igra, Grafika);
            break;
        case WM_PAINT:
            HDC hDC;
            PAINTSTRUCT ps;
            hDC = BeginPaint(hwnd, &ps);
            Grafika.Narisi_Tabelo(hDC, Igra);
            EndPaint(hwnd, &ps);
            break;
        case WM_SIZE:
            Grafika.Inicializiraj(hwnd, Igra, Grafika.Barva_1, Grafika.Barva_Robu_1, Grafika.Barva_2, Grafika.Barva_Robu_2);
            InvalidateRect(hwnd, NULL, TRUE);
            break;
        case WM_DESTROY:
            PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
            break;
        default:                      /* for messages that we don't deal with */
            return DefWindowProc (hwnd, message, wParam, lParam);
    }
    return 0;
}
